# WebChess

Pieces borrowed from https://www.chess.com/