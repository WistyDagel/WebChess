const { Chess } = require('chess.js')
const chess = new Chess();

// // while (!chess.game_over()) {
// //     const moves = chess.moves()
// //     // const move = moves[Math.floor(Math.random() * moves.length)]
// //     chess.move(move)
// // }

console.log(chess.move('Nf3'));
chess.move('e6');
chess.move('e4');

console.log(chess.history());

console.log(chess.ascii());